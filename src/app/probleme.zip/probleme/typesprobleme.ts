export interface ITypeProbleme {
    id: number;
    descriptionTypeProbleme: string;
}
